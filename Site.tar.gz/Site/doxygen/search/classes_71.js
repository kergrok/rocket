var searchData=
[
  ['quad',['Quad',['../classQuad.html',1,'']]]
];
