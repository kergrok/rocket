var searchData=
[
  ['solve_2ecpp',['Solve.cpp',['../Solve_8cpp.html',1,'']]]
];
